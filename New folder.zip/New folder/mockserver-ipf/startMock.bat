java -jar mockserver-executable.jar -serverPort 30161 > mockserver.out 2>&1 &
