#!/bin/sh

PROCESS_ID=$(ps aux | grep 'java' | grep 'mockserver-executable.jar' | awk '{print $2}')

if [ ! -z "$PROCESS_ID" -a "$PROCESS_ID"!=" " ]; then
	echo "Stoping mock server.."
	kill $PROCESS_ID
	wait
	echo "Done"
fi

