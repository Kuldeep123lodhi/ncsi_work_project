#!/bin/bash
java -Dspring.profiles.active=$env -Dspring.config.location=/config/mockrules.properties -Dcom.sun.management.jmxremote.port=9999 -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.authenticate=false -jar /opt/mockserver-ipf/mockserver-ipf.jar
