nohup ./startMock.sh &
