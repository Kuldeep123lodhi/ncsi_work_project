#!/bin/sh
MOCKSERVER_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SIMULATOR_PORT=30161
SIMULATOR_SECURE_PORT=30160
if [ ! -z "$1" -a "$1"!=" " ]; then
	SIMULATOR_PORT=$1
fi
cd $MOCKSERVER_DIR
java -jar mockserver-executable.jar -serverPort $SIMULATOR_PORT > mockserver.out 2>&1 &
#java -jar mockserver-executable.jar -serverPort $SIMULATOR_PORT -securePort $SIMULATOR_SECURE_PORT > mockserver.out 2>&1 &
