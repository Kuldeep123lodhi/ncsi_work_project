# Manage Service Qualification Service Channel Orchestration
Manage Service Qualification Service will handle all SOAP message request for Manage Service Qualification related operations.
The microservice will receive SOAP request, transform from XML to JSON, and send json to SRI.

# Package Name
## 1. Configuration
Configuration registers all configuration for this microservice.

## 2. Rest
Rest responsibility for sending message to downstream systems.

## 3. Service
Service responsibility for all business logic of this microservice.

## 4. Endpoint
Endpoint exposes all interfaces for this microservice
### https://servername:port/ipf-co/xxx/yyy
### Operations:
#### 1. xxx


# How to run and use APIs

# Deployment

# Testing

