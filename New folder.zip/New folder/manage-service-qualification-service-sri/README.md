# Manage Service QualificationService System Of Records Integration
Manage Service QualificationService will handle all Rest request for Manage Appointment.
The microservice will receive Rest request, Transformation and sent SOAP/REST requests 
to downstream systems.

# Package Name
## 1. Controller
Controller will expose all interface for this microservice
### a. https://servername:port:/xxx/yyy

## 2. Service
Service responsibility for all business logic of this microservice.

# How to run and use APIs

# Deployment

# Testing
