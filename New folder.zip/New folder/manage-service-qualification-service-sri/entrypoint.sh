#!/bin/bash
export OPTIONS="-Djavax.net.ssl.trustStore=/config/wsfDeliveryCertificate.jks -Djavax.net.ssl.trustStorePassword=wsfdeliveryssl -Djavax.net.ssl.trustStoreType=JKS"
if [[ "$env" == "pt" ]]
then
	#export ENV LD_PRELOAD="/opt/dynatrace/paasInstaller_Unix_all_uat/agent/lib64/liboneagentproc.so"
	#sh -x /opt/dynatrace/paasInstaller_Unix_all_uat/dynatrace-agent64.sh
	OPTIONS="-Djavax.net.ssl.trustStore=/config/wsfDeliveryCertificate.jks -Djavax.net.ssl.trustStorePassword=wildcardkey -Djavax.net.ssl.trustStoreType=JKS"
elif [[ "$env" == "prod" ]] || [[ "$env" == "dr" ]]
then
	export ENV LD_PRELOAD="/opt/dynatrace/paasInstaller_Unix_all_prod/agent/lib64/liboneagentproc.so"
	sh -x /opt/dynatrace/paasInstaller_Unix_all_prod/dynatrace-agent64.sh
	OPTIONS="-Djavax.net.ssl.trustStore=/config/jetty.ks -Djavax.net.ssl.trustStorePassword=sdpca2016 -Djavax.net.ssl.trustStoreType=JKS"
fi
java -Dspring.profiles.active=$env -Dspring.config.location=/config/manage-service-qualification-service-sri.properties $OPTIONS -jar /opt/manage-service-qualification-service-sri/manage-service-qualification-service-sri.jar
